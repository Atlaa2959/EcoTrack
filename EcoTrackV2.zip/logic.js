/**
 * EcoTrack - Responsive Dashboard Logic
 * Firebase Auth (email/password) - session via onAuthStateChanged
 */

(function () {
  'use strict';

  // --- Firebase (fill in your config in Firebase Console) ---
  const firebaseConfig = {
    apiKey: 'AIzaSyC2zKXKMBK7A65Yl-MxdIqHDSjAj2pTaHM',
    authDomain: 'ecotrack-1-35951.firebaseapp.com',
    projectId: 'ecotrack-1-35951',
    storageBucket: 'ecotrack-1-35951.firebasestorage.app',
    messagingSenderId: '533122002789',
    appId: '1:533122002789:web:cd146c8633d27d9e233b8c'
  };

  let firebaseApp = null;
  let firebaseAuth = null;
  let db = null;
  function getAuth() {
    if (!firebaseAuth && typeof firebase !== 'undefined' && firebase.app) {
      firebaseApp = firebase.app();
      if (firebase.auth) firebaseAuth = firebase.auth();
    }
    return firebaseAuth;
  }
  function getDb() {
    if (!db && typeof firebase !== 'undefined' && firebase.firestore) db = firebase.firestore();
    return db;
  }
  function initFirebase() {
    if (typeof firebase === 'undefined' || !firebase.initializeApp) return;
    try {
      firebaseApp = firebase.initializeApp(firebaseConfig);
      firebaseAuth = firebase.auth();
      db = firebase.firestore();
    } catch (e) {
      if (e && e.code === 'app/duplicate-app') {
        firebaseApp = firebase.app();
        firebaseAuth = firebase.auth();
        db = firebase.firestore();
      } else {
        console.warn('Firebase init failed (check firebaseConfig):', e.message);
      }
    }
  }

  const STORAGE_STATE = 'ecotrack_state';
  const STORAGE_THEME = 'theme';
  const STORAGE_NOTIFICATIONS = 'ecotrack_notifications';

  function getDefaultUserData() {
    return {
      streak: 0,
      totalPoints: 0,
      friendCount: 2,
      trackedDays: [],
      streakCountedDays: [],
      activeChallenges: { bringFood: 0, highScore: 0, walkBike: 0 },
      lastEntryDate: null,
      dailyReminders: { date: null, h8: false, h12: false, h18: false },
      lastCalc: null,
      avatarDataUrl: null,
      displayName: null,
      email: null,
      friends: [],
      friendRequests: [],
      rejectCounts: {},
      blockedUsers: []
    };
  }

  /** Normalize breakdown from Firestore (may be plain object or Firestore snapshot) to plain object. */
  function normalizeBreakdown(b) {
    if (!b || typeof b !== 'object') return { transport: 0, food: 0, digital: 0, bonus: 0 };
    return {
      transport: b.transport != null ? Number(b.transport) : 0,
      food: b.food != null ? Number(b.food) : 0,
      digital: b.digital != null ? Number(b.digital) : 0,
      bonus: b.bonus != null ? Number(b.bonus) : 0
    };
  }

  /** Normalize lastCalc from Firestore so nested breakdown is a plain object. */
  function normalizeLastCalc(lc) {
    if (!lc || typeof lc !== 'object') return null;
    var score = lc.score != null ? Number(lc.score) : 0;
    var date = lc.date != null ? String(lc.date) : null;
    var breakdown = normalizeBreakdown(lc.breakdown);
    return { score: score, date: date, breakdown: breakdown };
  }

  function applyUserDataToState(data) {
    if (!data) return;
    state.streak = data.streak != null ? data.streak : 0;
    state.totalPoints = data.totalPoints != null ? data.totalPoints : 0;
    state.friendCount = data.friendCount != null ? data.friendCount : (Array.isArray(data.friends) ? data.friends.length : 0);
    state.trackedDays = Array.isArray(data.trackedDays) ? data.trackedDays.slice() : [];
    state.streakCountedDays = Array.isArray(data.streakCountedDays) ? data.streakCountedDays.slice() : [];
    state.activeChallenges = data.activeChallenges && typeof data.activeChallenges === 'object'
      ? { bringFood: data.activeChallenges.bringFood != null ? data.activeChallenges.bringFood : 0, highScore: data.activeChallenges.highScore != null ? data.activeChallenges.highScore : 0, walkBike: data.activeChallenges.walkBike != null ? data.activeChallenges.walkBike : 0 }
      : { bringFood: 0, highScore: 0, walkBike: 0 };
    state.lastEntryDate = data.lastEntryDate != null && data.lastEntryDate !== '' ? data.lastEntryDate : null;
    state.dailyReminders = data.dailyReminders && typeof data.dailyReminders === 'object' ? data.dailyReminders : { date: null, h8: false, h12: false, h18: false };
    state.lastCalc = normalizeLastCalc(data.lastCalc);
    state.avatarDataUrl = data.avatarDataUrl || null;
    state.friends = Array.isArray(data.friends) ? data.friends.slice() : [];
    state.friendRequests = Array.isArray(data.friendRequests) ? data.friendRequests.slice().map(function (r) { return { fromUid: r.fromUid, displayName: r.displayName || 'Felhasználó', fromEmail: r.fromEmail || null }; }) : [];
    state.rejectCounts = data.rejectCounts && typeof data.rejectCounts === 'object' ? data.rejectCounts : {};
    state.blockedUsers = Array.isArray(data.blockedUsers) ? data.blockedUsers.slice() : [];
    if (state.currentUser && data.displayName != null) state.currentUser.displayName = data.displayName;
    else if (state.currentUser && (data.displayName == null || data.displayName === '') && state.currentUser.email) state.currentUser.displayName = state.currentUser.email;
  }

  function getTodayString() {
    var d = new Date();
    var y = d.getFullYear();
    var m = String(d.getMonth() + 1).padStart(2, '0');
    var day = String(d.getDate()).padStart(2, '0');
    return y + '-' + m + '-' + day;
  }

  const CO2_PER_KM = { plane: 350, car: 160, bus: 90, bike: 0, walk: 0 };
  const CO2_FOOD = { vegan: 12, otthoni: 30, bufe: 110, etterem: 200 };
  const CO2_DIGITAL_PER_HOUR = 48;
  
  const BONUS_BOTTLE = -50;
  const BONUS_BAG = -30;
  const BONUS_MEATLESS = -80;
  const BONUS_RECYCLE = -40;

  const CO2_PER_POINT_PENALTY = 180;
  const MAX_POINT_PENALTY = 97;

  /** Earned badges (Kitűzők) derived from user doc - same rules as profile. */
  var BADGES_CONFIG = [
    { id: '7days', icon: 'medal', label: '7 nap használat', color: 'text-amber-600', earned: function (d) { var arr = d.streakCountedDays || []; return Array.isArray(arr) && arr.length >= 7; } },
    { id: '10streak', icon: 'star', label: '10 napos sorozat', color: 'text-yellow-500', earned: function (d) { return (d.streak || 0) >= 10; } },
    { id: '1000pts', icon: 'shield', label: '1000 pont', color: 'text-emerald-500', earned: function (d) { return (d.totalPoints || 0) >= 1000; } },
    { id: 'bike', icon: 'bike', label: 'Bringa/gyalog 3x', color: 'text-blue-500', earned: function (d) { var ac = d.activeChallenges; return ac && ac.walkBike >= 3; } },
    { id: 'vegan', icon: 'leaf', label: 'Környezetbarát evés', color: 'text-green-500', earned: function (d) { var ac = d.activeChallenges; return ac && ac.bringFood >= 3; } },
    { id: 'highscore', icon: 'target', label: 'Magas pontszám', color: 'text-amber-500', earned: function (d) { var ac = d.activeChallenges; return ac && ac.highScore >= 3; } }
  ];

  function getEarnedBadges(userData) {
    if (!userData || typeof userData !== 'object') return [];
    return BADGES_CONFIG.filter(function (b) { return b.earned(userData); }).map(function (b) { return { icon: b.icon, label: b.label, color: b.color || 'text-gray-500' }; });
  }

  function renderBadgesIntoEl(badges, containerEl) {
    if (!containerEl) return;
    if (!badges || badges.length === 0) {
      containerEl.innerHTML = '<span class="text-xs text-gray-500">Még nincs kitűzője</span>';
      return;
    }
    var html = badges.map(function (b) {
      return '<span class="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-gray-100 dark:bg-gray-700 ' + (b.color || '') + '" title="' + escapeHtml(b.label) + '"><i data-lucide="' + b.icon + '" class="w-4 h-4"></i><span class="text-xs">' + escapeHtml(b.label) + '</span></span>';
    }).join('');
    containerEl.innerHTML = html;
    if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
  }

  let state = {
    currentUser: null,
    streak: 0,
    totalPoints: 0,
    friendCount: 0,
    trackedDays: [],
    streakCountedDays: [],
    activeChallenges: { bringFood: 0, highScore: 0, walkBike: 0 },
    lastEntryDate: null,
    dailyReminders: { date: null, h8: false, h12: false, h18: false },
    lastCalc: null,
    avatarDataUrl: null,
    darkMode: false,
    notifications: false,
    friends: [],
    friendRequests: [],
    rejectCounts: {},
    blockedUsers: []
  };

  var friendRequestToastShownFromUids = {};

  /** Cache of friend UID -> displayName for chat notifications. Updated when leaderboard or friends list is rendered. */
  var friendUidToNameCache = {};
  var chatNotificationUnsubscribes = [];
  /** Per-chat count of unread messages (senderId !== me && isRead === false). Persisted via Firestore isRead field. */
  var chatUnreadCountByChatId = {};

  function setupChatNotificationListeners() {
    var firestoreDb = getDb();
    var me = state.currentUser ? state.currentUser.uid : null;
    if (!firestoreDb || !me || !state.friends || state.friends.length === 0) {
      chatNotificationUnsubscribes.forEach(function (unsub) { if (typeof unsub === 'function') unsub(); });
      chatNotificationUnsubscribes = [];
      chatUnreadCountByChatId = {};
      return;
    }
    chatNotificationUnsubscribes.forEach(function (unsub) { if (typeof unsub === 'function') unsub(); });
    chatNotificationUnsubscribes = [];
    state.friends.forEach(function (friendUid) {
      var chatId = getChatId(me, friendUid);
      var messagesRef = firestoreDb.collection('chats').doc(chatId).collection('messages');
      var unsub = messagesRef.orderBy('timestamp', 'asc').onSnapshot(function (snap) {
        if (!snap || !snap.docs) {
          chatUnreadCountByChatId[chatId] = 0;
          updateNavNotifications();
          return;
        }
        var unreadCount = 0;
        var lastFromOther = null;
        snap.docs.forEach(function (doc) {
          var data = doc.data() || {};
          var senderId = data.senderId;
          var isRead = data.isRead;
          if (senderId !== me && isRead !== true) {
            unreadCount++;
            lastFromOther = doc;
          }
        });
        var prev = chatUnreadCountByChatId[chatId];
        chatUnreadCountByChatId[chatId] = unreadCount;
        if (unreadCount > (prev || 0) && lastFromOther && currentChatFriendUid !== friendUid) {
          var fromName = friendUidToNameCache[friendUid] || 'Barát';
          showToast('Új üzenet tőle: ' + fromName, { icon: 'message-circle' });
        }
        updateNavNotifications();
      }, function () {});
      chatNotificationUnsubscribes.push(unsub);
    });
  }

  let chartDonut = null;
  let calendarCurrent = { year: new Date().getFullYear(), month: new Date().getMonth() };
  let firestoreUnsubscribe = null;

  if (typeof Chart !== 'undefined' && typeof ChartDataLabels !== 'undefined') {
    Chart.register(ChartDataLabels);
  }

  /**
   * Refresh all UI from current state (streak, points, profile, charts, water, daily lock).
   * Call after loading from Firestore or when state changes (e.g. real-time snapshot).
   * When state.lastCalc belongs to today, aggressively updates score circle, chart, forest, water.
   */
  function refreshUIFromState() {
    var todayStr = getTodayString();
    var todayDateString = new Date().toDateString();
    updateNavStreak();
    updateNavNotifications();
    syncProfileAndSettings();
    updateAvatarDisplays();
    renderProfile();
    renderLeaderboard();
    if (document.getElementById('calendar-grid') && document.getElementById('modal-calendar') && !document.getElementById('modal-calendar').classList.contains('hidden')) {
      renderCalendar();
    }
    var lastCalcIsToday = state.lastCalc && state.lastCalc.score != null &&
      (state.lastEntryDate === todayStr || (state.lastCalc.date && state.lastCalc.date === todayDateString));
    if (lastCalcIsToday) {
      var score = Number(state.lastCalc.score);
      var breakdown = state.lastCalc.breakdown && typeof state.lastCalc.breakdown === 'object'
        ? normalizeBreakdown(state.lastCalc.breakdown)
        : { transport: 0, food: 0, digital: 0, bonus: 0 };
      var scoreEl = document.getElementById('results-score-circle');
      if (scoreEl) scoreEl.textContent = score;
      drawDonut(breakdown);
      drawForest(score);
      fetchAveragesAndRedraw(score);
      updateWaterLevel(score);
    } else {
      var scoreEl2 = document.getElementById('results-score-circle');
      if (scoreEl2) scoreEl2.textContent = '0';
      drawDonut({ transport: 0, food: 0, digital: 0, bonus: 0 });
      drawForest(0);
      updateWaterLevel(10);
    }
    setDailyCalcFormVisibility();
  }

  /**
   * Show or hide the calculation form based on whether the user already completed today.
   * When already done today: hide form, show "already done" message. Otherwise show form.
   */
  function setDailyCalcFormVisibility() {
    var todayStr = getTodayString();
    var alreadyDoneToday = state.lastEntryDate === todayStr || (state.lastCalc && state.lastCalc.date === new Date().toDateString());
    var formEl = document.getElementById('calc-form');
    var cardEl = formEl ? formEl.closest('.rounded-2xl') : null;
    var existingMsg = document.getElementById('calc-already-done-msg');
    if (existingMsg) existingMsg.remove();
    if (!formEl) return;
    if (alreadyDoneToday) {
      formEl.classList.add('hidden');
      if (cardEl) {
        var msg = document.createElement('div');
        msg.id = 'calc-already-done-msg';
        msg.className = 'flex flex-col items-center justify-center flex-1 py-8 px-4 text-center';
        msg.innerHTML = '<p class="text-lg font-bold text-emerald-600 dark:text-emerald-400 mb-2">Mai nap teljesítve</p><p class="text-sm text-gray-600 dark:text-gray-400">Eredményeid jobb oldalon láthatók.</p>';
        cardEl.appendChild(msg);
      }
    } else {
      formEl.classList.remove('hidden');
    }
  }

  function updateWaterLevel(score) {
    const waterLevelDiv = document.getElementById('water-level');
    if (waterLevelDiv) {
      const heightPercentage = Math.max(10, score);
      waterLevelDiv.style.height = heightPercentage + '%';
    }
  }

  function getStateKey() {
    return state.currentUser && state.currentUser.uid ? STORAGE_STATE + '_' + state.currentUser.uid : null;
  }

  /**
   * Load user data from Firestore. Uses real-time onSnapshot so changes on other devices update UI.
   * Resolves when first snapshot is applied. Call showMain() after this.
   */
  function loadAppStateFromFirestore(user) {
    if (!user || !user.uid) return Promise.resolve();
    if (firestoreUnsubscribe && typeof firestoreUnsubscribe === 'function') {
      firestoreUnsubscribe();
      firestoreUnsubscribe = null;
    }
    var firestoreDb = getDb();
    if (!firestoreDb) {
      applyUserDataToState(getDefaultUserData());
      return Promise.resolve();
    }
    var userRef = firestoreDb.collection('users').doc(user.uid);
    return new Promise(function (resolve, reject) {
      var resolved = false;
      function applyAndRefresh(data) {
        var prevRequestFromUids = (state.friendRequests || []).map(function (r) { return r.fromUid; });
        applyUserDataToState(data);
        checkNewFriendRequestsAndShowToasts(prevRequestFromUids);
        setupChatNotificationListeners();
        if (document.getElementById('main-app') && !document.getElementById('main-app').classList.contains('hidden')) {
          refreshUIFromState();
        }
        if (!resolved) {
          resolved = true;
          resolve();
        }
      }
      firestoreUnsubscribe = userRef.onSnapshot(
        function (doc) {
          var data;
          if (doc.exists) {
            data = doc.data();
          } else {
            data = getDefaultUserData();
            if (state.currentUser && (state.currentUser.displayName || state.currentUser.email)) {
              data.displayName = state.currentUser.displayName || state.currentUser.email;
            }
            if (state.currentUser && state.currentUser.email) data.email = state.currentUser.email;
            data.friends = data.friends || [];
            data.friendRequests = data.friendRequests || [];
            data.rejectCounts = data.rejectCounts || {};
            data.blockedUsers = data.blockedUsers || [];
            userRef.set(data, { merge: true }).catch(function (e) { console.error('Firestore init set failed:', e); });
          }
          if (data) {
            applyAndRefresh(data);
          }
        },
        function (err) {
          console.error('Firestore snapshot error:', err);
          if (!resolved) {
            resolved = true;
            applyUserDataToState(getDefaultUserData());
            resolve();
          }
        }
      );
    });
  }

  function loadAppState() {
    /* User data is loaded from Firestore in loadAppStateFromFirestore() before showMain(). */
  }

  /**
   * Save current user data to Firestore. Returns a Promise.
   * Call .catch() at call sites to handle errors.
   */
  function saveAppState() {
    if (!state.currentUser || !state.currentUser.uid) return Promise.resolve();
    var firestoreDb = getDb();
    if (!firestoreDb) return Promise.resolve();
    var data = {
      streak: state.streak,
      totalPoints: state.totalPoints,
      friendCount: state.friends ? state.friends.length : 0,
      trackedDays: state.trackedDays,
      streakCountedDays: state.streakCountedDays,
      activeChallenges: state.activeChallenges,
      lastEntryDate: state.lastEntryDate,
      dailyReminders: state.dailyReminders,
      lastCalc: state.lastCalc,
      avatarDataUrl: state.avatarDataUrl,
      displayName: state.currentUser ? state.currentUser.displayName : null,
      email: state.currentUser ? (state.currentUser.email || null) : null,
      friends: state.friends || [],
      friendRequests: state.friendRequests || [],
      rejectCounts: state.rejectCounts || {},
      blockedUsers: state.blockedUsers || []
    };
    return firestoreDb.collection('users').doc(state.currentUser.uid).set(data, { merge: true });
  }

  function loadPrefs() {
    try {
      state.darkMode = localStorage.getItem(STORAGE_THEME) === 'dark';
      state.notifications = localStorage.getItem(STORAGE_NOTIFICATIONS) === 'true';
    } catch (_) {}
  }

  function saveTheme() {
    try { localStorage.setItem(STORAGE_THEME, state.darkMode ? 'dark' : 'light'); } catch(e) {}
  }

  function saveNotifications() {
    try { localStorage.setItem(STORAGE_NOTIFICATIONS, state.notifications ? 'true' : 'false'); } catch(e) {}
  }

  function applyPrefs() {
    if (state.darkMode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
    
    ['toggle-dark', 'toggle-notifications'].forEach(id => {
      let btn = document.getElementById(id);
      let knob = document.getElementById(id + '-knob');
      let val = id === 'toggle-dark' ? state.darkMode : state.notifications;
      if (btn) {
        btn.classList.toggle('bg-emerald-500', val);
        btn.classList.toggle('bg-gray-300', !val);
      }
      if (knob) knob.classList.toggle('translate-x-5', val);
    });
  }

  function setNotifications(on) {
    if (on && "Notification" in window) {
      Notification.requestPermission().then(function (permission) {
        if (permission === "granted") {
          state.notifications = true;
          saveNotifications();
          applyPrefs();
          new Notification("EcoTrack", { body: "Az értesítések bekapcsolva! Napi emlékeztetők 8:00, 12:00 és 18:00 környékén." });
        } else {
          state.notifications = false;
          saveNotifications();
          applyPrefs();
          alert("A böngésző blokkolta az értesítéseket. Kérlek, engedélyezd a böngésző beállításaiban!");
        }
      });
    } else {
      state.notifications = !!on;
      saveNotifications();
      applyPrefs();
    }
  }

  function checkFixedTimeReminders() {
    if (!state.notifications || !("Notification" in window) || Notification.permission !== "granted") return;
    if (!state.currentUser) return;

    var todayStr = getTodayString();
    if (state.lastEntryDate === todayStr) return;

    if (!state.dailyReminders || state.dailyReminders.date !== todayStr) {
      state.dailyReminders = { date: todayStr, h8: false, h12: false, h18: false };
    }

    var now = new Date();
    var currentHour = now.getHours();
    var shouldSave = false;

    if (currentHour >= 8 && currentHour < 12 && !state.dailyReminders.h8) {
      new Notification("EcoTrack Jó reggelt!", { body: "Ne felejtsd el kitölteni a mai kalkulátort!" });
      state.dailyReminders.h8 = true;
      shouldSave = true;
    } else if (currentHour >= 12 && currentHour < 18 && !state.dailyReminders.h12) {
      new Notification("EcoTrack Délutáni emlékeztető", { body: "Még nem töltötted ki a mai kalkulátort. Tartsd életben a sorozatod!" });
      state.dailyReminders.h12 = true;
      shouldSave = true;
    } else if (currentHour >= 18 && !state.dailyReminders.h18) {
      new Notification("EcoTrack Esti figyelmeztetés", { body: "Mindjárt vége a napnak! Töltsd ki a kalkulátort gyorsan!" });
      state.dailyReminders.h18 = true;
      shouldSave = true;
    }

    if (shouldSave) saveAppState().catch(function (e) { console.error('Save failed:', e); });
  }

  function showAuth() {
    document.getElementById('auth-screen').classList.remove('hidden');
    document.getElementById('auth-screen').classList.add('flex');
    document.getElementById('main-app').classList.add('hidden');
  }

  function showMain() {
    document.getElementById('auth-screen').classList.add('hidden');
    document.getElementById('auth-screen').classList.remove('flex');
    document.getElementById('main-app').classList.remove('hidden');
    document.getElementById('main-app').classList.add('flex');

    refreshUIFromState();
  }

  function setCurrentUserFromFirebaseUser(fbUser, displayNameOverride) {
    if (!fbUser) {
      state.currentUser = null;
      return;
    }
    var name = displayNameOverride != null && displayNameOverride !== '' ? displayNameOverride : ((fbUser.displayName && fbUser.displayName.trim()) || fbUser.email || 'Felhasználó');
    state.currentUser = {
      uid: fbUser.uid,
      email: fbUser.email || '',
      displayName: name
    };
  }

  /** Returns a Promise that resolves to true if displayName is already taken by another user (or by any user if excludeUid is null). */
  function isDisplayNameTaken(displayName, excludeUid) {
    var firestoreDb = getDb();
    if (!firestoreDb || !displayName || !String(displayName).trim()) return Promise.resolve(false);
    var name = String(displayName).trim();
    return firestoreDb.collection('users').where('displayName', '==', name).limit(1).get().then(function (snap) {
      if (!snap || snap.empty) return false;
      var doc = snap.docs[0];
      if (excludeUid && doc.id === excludeUid) return false;
      return true;
    }).catch(function () { return false; });
  }

  function registerWithFirebase(email, password, displayName) {
    var auth = getAuth();
    if (!auth) return Promise.reject(new Error('Firebase Auth nem elérhető. Ellenőrizd a firebaseConfig-ot.'));
    return auth.createUserWithEmailAndPassword(email, password)
      .then(function (userCredential) {
        var name = (displayName != null && String(displayName).trim() !== '') ? String(displayName).trim() : email;
        setCurrentUserFromFirebaseUser(userCredential.user, name);
        return true;
      });
  }

  function loginWithFirebase(email, password) {
    var auth = getAuth();
    if (!auth) return Promise.reject(new Error('Firebase Auth nem elérhető. Ellenőrizd a firebaseConfig-ot.'));
    return auth.signInWithEmailAndPassword(email, password)
      .then(function (userCredential) {
        setCurrentUserFromFirebaseUser(userCredential.user);
        return true;
      });
  }

  function logout() {
    if (firestoreUnsubscribe && typeof firestoreUnsubscribe === 'function') {
      firestoreUnsubscribe();
      firestoreUnsubscribe = null;
    }
    chatNotificationUnsubscribes.forEach(function (unsub) { if (typeof unsub === 'function') unsub(); });
    chatNotificationUnsubscribes = [];
    chatUnreadCountByChatId = {};
    var auth = getAuth();
    if (auth) {
      try { auth.signOut(); } catch (_) {}
    }
    var def = getDefaultUserData();
    state.streak = def.streak;
    state.totalPoints = def.totalPoints;
    state.friendCount = def.friendCount;
    state.trackedDays = def.trackedDays.slice();
    state.streakCountedDays = def.streakCountedDays.slice();
    state.activeChallenges = { bringFood: def.activeChallenges.bringFood, highScore: def.activeChallenges.highScore, walkBike: def.activeChallenges.walkBike };
    state.lastEntryDate = def.lastEntryDate;
    state.dailyReminders = def.dailyReminders;
    state.lastCalc = def.lastCalc;
    state.avatarDataUrl = def.avatarDataUrl;
    state.friends = [];
    state.friendRequests = [];
    state.rejectCounts = {};
    state.blockedUsers = [];
    state.currentUser = null;
    closeModals();
    showAuth();
  }

  function runSplash() {
    const splash = document.getElementById('splash');
    if (!splash) return;
    
    setTimeout(function () {
      if (typeof gsap !== 'undefined') {
        gsap.to(splash, { opacity: 0, duration: 0.3, onComplete: onSplashDone });
      } else {
        splash.style.opacity = '0';
        setTimeout(onSplashDone, 300);
      }
    }, 1000);
  }

  function onSplashDone() {
    var splash = document.getElementById('splash');
    if (splash) splash.style.display = 'none';
    var auth = getAuth();
    if (auth && state.currentUser && state._firestoreLoaded) showMain();
    else if (!state.currentUser) showAuth();
  }

  function setupAuthStateListener() {
    var auth = getAuth();
    if (!auth) {
      if (state.currentUser) showMain();
      else showAuth();
      return;
    }
    auth.onAuthStateChanged(function (user) {
      setCurrentUserFromFirebaseUser(user || null);
      var splash = document.getElementById('splash');
      if (user) {
        loadAppStateFromFirestore(user).then(function () {
          state._firestoreLoaded = true;
          if (splash) splash.style.display = 'none';
          showMain();
        }).catch(function (err) {
          console.error('Firestore load failed:', err);
          if (splash) splash.style.display = 'none';
          applyUserDataToState(getDefaultUserData());
          state._firestoreLoaded = true;
          showMain();
        });
      } else {
        state._firestoreLoaded = false;
        if (firestoreUnsubscribe && typeof firestoreUnsubscribe === 'function') {
          firestoreUnsubscribe();
          firestoreUnsubscribe = null;
        }
        var def = getDefaultUserData();
        state.streak = def.streak;
        state.totalPoints = def.totalPoints;
        state.friendCount = def.friendCount;
        state.trackedDays = def.trackedDays.slice();
        state.streakCountedDays = def.streakCountedDays.slice();
        state.activeChallenges = { bringFood: def.activeChallenges.bringFood, highScore: def.activeChallenges.highScore, walkBike: def.activeChallenges.walkBike };
        state.lastEntryDate = def.lastEntryDate;
        state.dailyReminders = def.dailyReminders;
        state.lastCalc = def.lastCalc;
        state.avatarDataUrl = def.avatarDataUrl;
        state.friends = [];
        state.friendRequests = [];
        state.rejectCounts = {};
        state.blockedUsers = [];
        state.currentUser = null;
        if (splash && splash.style.display === 'none') showAuth();
      }
    });
  }

  function refreshLucide() {
    if (typeof lucide !== 'undefined' && lucide.createIcons) {
      try { 
        lucide.createIcons(); 
      } catch(e) {
        console.error("Lucide hiba:", e);
      }
    }
  }

  function updateNavStreak() {
    const el = document.getElementById('nav-streak');
    if (el) el.textContent = state.streak;
  }

  function updateNavNotifications() {
    var badge = document.getElementById('nav-notifications-badge');
    var list = document.getElementById('notifications-list');
    var empty = document.getElementById('notifications-empty');
    var friendCount = (state.friendRequests && state.friendRequests.length) || 0;
    var unreadChats = getUnreadChatNotifications();
    var unreadChatTotal = unreadChats.reduce(function (sum, u) { return sum + (u.unreadCount || 0); }, 0);
    var totalCount = friendCount + unreadChatTotal;
    if (badge) {
      if (totalCount > 0) {
        badge.textContent = totalCount > 99 ? '99+' : totalCount;
        badge.classList.remove('hidden');
      } else {
        badge.classList.add('hidden');
      }
    }
    if (list && empty) {
      if (totalCount === 0) {
        list.innerHTML = '';
        empty.classList.remove('hidden');
        return;
      }
      empty.classList.add('hidden');
      var html = '';
      (state.friendRequests || []).forEach(function (req) {
        var name = (req.displayName && req.displayName.trim()) ? escapeHtml(req.displayName.trim()) : 'Valaki';
        html += '<li class="notification-item flex items-center gap-3 p-3 rounded-xl" data-type="friend-request" data-from-uid="' + escapeHtml(req.fromUid) + '"><i data-lucide="user-plus" class="w-5 h-5 text-emerald-500 shrink-0"></i><span class="text-sm font-medium text-gray-800 dark:text-white">' + name + ' baráti meghívást küldött</span></li>';
      });
      unreadChats.forEach(function (u) {
        var name = escapeHtml(u.friendName || 'Barát');
        html += '<li class="notification-item flex items-center gap-3 p-3 rounded-xl" data-type="chat" data-friend-uid="' + escapeHtml(u.friendUid) + '" data-friend-name="' + escapeHtml(u.friendName || 'Barát') + '"><i data-lucide="message-circle" class="w-5 h-5 notification-chat-icon shrink-0"></i><span class="text-sm font-medium text-gray-800 dark:text-white">Új üzenet: ' + name + '</span></li>';
      });
      list.innerHTML = html;
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
    }
  }

  /** Returns list of { friendUid, friendName, unreadCount } for chats with unread messages (isRead === false from others). */
  function getUnreadChatNotifications() {
    var me = state.currentUser ? state.currentUser.uid : null;
    if (!me || !state.friends || state.friends.length === 0) return [];
    var out = [];
    state.friends.forEach(function (friendUid) {
      var chatId = getChatId(me, friendUid);
      var unread = chatUnreadCountByChatId[chatId] || 0;
      if (unread > 0) {
        out.push({
          friendUid: friendUid,
          friendName: friendUidToNameCache[friendUid] || 'Barát',
          unreadCount: unread
        });
      }
    });
    return out;
  }

  function toggleNotificationsDropdown() {
    var dd = document.getElementById('notifications-dropdown');
    if (!dd) return;
    if (dd.classList.contains('hidden')) {
      dd.classList.remove('hidden');
      dd.classList.add('show');
      updateNavNotifications();
    } else {
      dd.classList.add('hidden');
      dd.classList.remove('show');
    }
  }

  function closeNotificationsDropdown() {
    var dd = document.getElementById('notifications-dropdown');
    if (dd) {
      dd.classList.add('hidden');
      dd.classList.remove('show');
    }
  }

  function syncProfileAndSettings() {
    const name = state.currentUser ? (state.currentUser.displayName || state.currentUser.email || 'Felhasználó') : '';
    const unameEl = document.getElementById('profile-username');
    const inputEl = document.getElementById('settings-username');
    if (unameEl) unameEl.textContent = name || 'Felhasználó';
    if (inputEl) inputEl.value = name;
  }

  function updateAvatarDisplays() {
    ['profile-avatar', 'settings-avatar'].forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      const icon = el.querySelector('.profile-avatar-icon, .settings-avatar-icon');
      if (state.avatarDataUrl) {
        el.style.backgroundImage = 'url(' + state.avatarDataUrl + ')';
        if (icon) icon.style.display = 'none';
      } else {
        el.style.backgroundImage = '';
        if (icon) icon.style.display = '';
      }
    });
  }

  function openModal(id) {
    const el = document.getElementById('modal-' + id);
    if(el) {
      el.classList.remove('hidden');
      el.classList.add('flex');
      if(id === 'calendar') renderCalendar();
    }
  }

  function closeModals() {
    document.querySelectorAll('.fixed.z-\\[60\\]').forEach(el => {
      el.classList.add('hidden');
      el.classList.remove('flex');
    });
    closeChatModal();
  }

  function getCo2Breakdown() {
    var vehicle = document.getElementById('calc-vehicle').value;
    var distance = parseFloat(document.getElementById('calc-distance').value) || 0;
    var food = document.getElementById('calc-food').value;
    var digitalInput = document.getElementById('calc-digital');
    var digital = parseFloat(digitalInput.value) || 0;
    if (digital > 24) digital = 24;
    
    var bonusBottle = document.getElementById('calc-bonus-bottle').checked;
    var bonusBag = document.getElementById('calc-bonus-bag').checked;
    var bonusMeatless = document.getElementById('calc-bonus-meatless').checked;
    var bonusRecycle = document.getElementById('calc-bonus-recycle').checked;

    var totalBonus = 0;
    if (bonusBottle) totalBonus += BONUS_BOTTLE;
    if (bonusBag) totalBonus += BONUS_BAG;
    if (bonusMeatless) totalBonus += BONUS_MEATLESS;
    if (bonusRecycle) totalBonus += BONUS_RECYCLE;

    var transportCo2 = Math.round((CO2_PER_KM[vehicle] || 0) * distance);
    var foodCo2 = CO2_FOOD[food] !== undefined ? CO2_FOOD[food] : 55;
    var digitalCo2 = Math.round(digital * CO2_DIGITAL_PER_HOUR);

    return {
      transport: transportCo2,
      food: foodCo2,
      digital: digitalCo2,
      bonus: totalBonus,
      total: Math.max(0, transportCo2 + foodCo2 + digitalCo2 + totalBonus)
    };
  }

  function co2ToScore(totalCo2) {
    if (totalCo2 <= 0) return 100;
    const penalty = Math.min(MAX_POINT_PENALTY, Math.floor(totalCo2 / CO2_PER_POINT_PENALTY));
    return Math.max(5, 100 - penalty);
  }

  function showResults(breakdown, score, hasFoodBonus, vehicle) {
    var today = new Date().toDateString();
    var todayStr = getTodayString();
    var alreadyCountedToday = state.streakCountedDays.indexOf(today) !== -1;

    state.lastCalc = { breakdown: breakdown, score: score, date: today };
    state.lastEntryDate = todayStr;
    state.totalPoints += score;
    if (!alreadyCountedToday) {
      state.streak = (state.streak || 0) + 1;
      state.streakCountedDays.push(today);
    }
    if (state.trackedDays.indexOf(today) === -1) state.trackedDays.push(today);
    
    var ac = state.activeChallenges;
    if (hasFoodBonus) ac.bringFood = Math.min(3, (ac.bringFood || 0) + 1);
    if (score > 80) ac.highScore = Math.min(3, (ac.highScore || 0) + 1);
    if (vehicle === 'bike' || vehicle === 'walk') ac.walkBike = Math.min(3, (ac.walkBike || 0) + 1);

    saveAppState().catch(function (e) { console.error('Save failed:', e); });
    updateNavStreak();
    renderProfile();
    renderLeaderboard();

    document.getElementById('results-score-circle').textContent = score;
    drawDonut(breakdown);
    drawForest(score);
    fetchAveragesAndRedraw(score);
    updateWaterLevel(score);
    
    if (typeof gsap !== 'undefined') {
      try {
        gsap.fromTo('#results-score-circle', { scale: 0.5, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.5, ease: 'back.out(1.7)' });
      } catch(e) {}
    }
  }

  function drawDonut(breakdown) {
    if (typeof Chart === 'undefined') return;
    
    const canvas = document.getElementById('chart-donut');
    if (!canvas) return;
    if (chartDonut) chartDonut.destroy();
    
    try {
      const ctx = canvas.getContext('2d');
      let data = [Math.max(0, breakdown.transport), Math.max(0, breakdown.food), Math.max(0, breakdown.digital), Math.abs(breakdown.bonus)];
      let colors = ['rgba(16, 185, 129, 0.85)', 'rgba(59, 130, 246, 0.85)', 'rgba(139, 92, 246, 0.85)', 'rgba(245, 158, 11, 0.85)'];
      let labels = ['Közlekedés', 'Étkezés', 'Digitális', 'Megspórolt'];
      
      let noData = data.every(val => val === 0);
      if(noData) {
          data = [1];
          colors = ['rgba(229, 231, 235, 0.3)']; 
          labels = ['Nincs adat'];
      }

      chartDonut = new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: labels,
          datasets: [{
            data: data,
            backgroundColor: colors,
            borderWidth: 0,
            hoverOffset: 4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false, 
          layout: {
            padding: { left: 45, right: 45, top: 30, bottom: 30 }
          },
          plugins: { 
            legend: { display: false },
            datalabels: {
              display: !noData,
              color: state.darkMode ? '#ffffff' : '#000000',
              backgroundColor: state.darkMode ? 'rgba(30, 41, 59, 0.9)' : 'rgba(255, 255, 255, 0.9)',
              borderColor: state.darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
              borderWidth: 1,
              borderRadius: 6,
              padding: { top: 4, bottom: 4, left: 6, right: 6 },
              formatter: (value, context) => {
                if (value === 0) return '';
                let sum = context.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                let percentage = (value * 100 / sum).toFixed(0) + "%";
                return context.chart.data.labels[context.dataIndex] + '\n' + percentage;
              },
              anchor: 'end',
              align: 'end',
              offset: 6,
              font: { weight: 'bold', size: 10 },
              textAlign: 'center'
            }
          },
          cutout: '68%' 
        }
      });
    } catch(e) {}
  }

  /**
   * Fetches the average score of the current user's friends for today.
   * Only friends with lastEntryDate === todayStr and a valid lastCalc.score are included.
   * @returns {Promise<number>} Average score or 0 if no data
   */
  function getFriendsTodayAverage() {
    var firestoreDb = getDb();
    if (!firestoreDb || !state.currentUser || !Array.isArray(state.friends) || state.friends.length === 0) return Promise.resolve(0);
    var todayStr = getTodayString();
    var promises = state.friends.map(function (friendUid) {
      return firestoreDb.collection('users').doc(friendUid).get().then(function (doc) {
        if (!doc || !doc.exists) return null;
        var d = doc.data();
        if (d.lastEntryDate !== todayStr || !d.lastCalc || typeof d.lastCalc.score !== 'number') return null;
        return d.lastCalc.score;
      });
    });
    return Promise.all(promises).then(function (scores) {
      var valid = scores.filter(function (s) { return s != null && !Number.isNaN(s); });
      if (valid.length === 0) return 0;
      return valid.reduce(function (a, b) { return a + b; }, 0) / valid.length;
    }).catch(function () { return 0; });
  }

  /**
   * Fetches the average score of all users who have a calculation for today (lastEntryDate === todayStr).
   * @returns {Promise<number>} Global average score or 0 if no data
   */
  function getGlobalTodayAverage() {
    var firestoreDb = getDb();
    if (!firestoreDb) return Promise.resolve(0);
    var todayStr = getTodayString();
    return firestoreDb.collection('users').where('lastEntryDate', '==', todayStr).get().then(function (snap) {
      if (!snap || !snap.docs || snap.docs.length === 0) return 0;
      var sum = 0;
      var count = 0;
      snap.docs.forEach(function (doc) {
        var d = doc.data();
        if (d.lastCalc && typeof d.lastCalc.score === 'number') { sum += d.lastCalc.score; count++; }
      });
      return count === 0 ? 0 : sum / count;
    }).catch(function () { return 0; });
  }

  /**
   * Fetches friends and global averages then redraws the forest with real data.
   */
  function fetchAveragesAndRedraw(score) {
    Promise.all([getFriendsTodayAverage(), getGlobalTodayAverage()]).then(function (arr) {
      drawForest(score, arr[0], arr[1]);
    }).catch(function () { drawForest(score, 0, 0); });
  }

  function drawForest(score, friendsAvg, nationalAvg) {
    const hasFriends = typeof friendsAvg === 'number' && !Number.isNaN(friendsAvg);
    const hasNational = typeof nationalAvg === 'number' && !Number.isNaN(nationalAvg);
    const friendsVal = (hasFriends && score > 0) ? Math.min(100, Math.max(0, Math.round(friendsAvg))) : (score > 0 ? Math.min(100, Math.max(0, score + Math.floor(Math.random() * 20) - 10)) : 0);
    const nationalVal = (hasNational && score > 0) ? Math.min(100, Math.max(0, Math.round(nationalAvg))) : (score > 0 ? 52 : 0);
    
    document.getElementById('tree-val-you').textContent = score;
    document.getElementById('tree-val-friends').textContent = friendsVal;
    document.getElementById('tree-val-avg').textContent = nationalVal;

    const scaleYou = 0.2 + (score / 100) * 0.9;
    const scaleFriends = 0.2 + (friendsVal / 100) * 0.9;
    const scaleAvg = 0.2 + (nationalVal / 100) * 0.9;

    const treeYou = document.getElementById('tree-svg-you');
    const treeFriends = document.getElementById('tree-svg-friends');
    const treeAvg = document.getElementById('tree-svg-avg');

    if(treeYou) treeYou.style.transform = `scale(${score === 0 ? 0.1 : scaleYou})`;
    if(treeFriends) treeFriends.style.transform = `scale(${score === 0 ? 0.1 : scaleFriends})`;
    if(treeAvg) treeAvg.style.transform = `scale(${score === 0 ? 0.1 : scaleAvg})`;
  }

  const MONTH_NAMES_HU = ['január', 'február', 'március', 'április', 'május', 'június', 'július', 'augusztus', 'szeptember', 'október', 'november', 'december'];

  function renderCalendar() {
    var grid = document.getElementById('calendar-grid');
    var title = document.getElementById('calendar-title');
    if (!grid || !title) return;
    
    var year = calendarCurrent.year;
    var month = calendarCurrent.month;
    title.textContent = year + '. ' + MONTH_NAMES_HU[month];

    var first = new Date(year, month, 1);
    var last = new Date(year, month + 1, 0);
    var startPad = first.getDay() === 0 ? 6 : first.getDay() - 1; 
    var daysInMonth = last.getDate();
    var today = new Date();

    var streakSet = new Set((state.streakCountedDays || []));

    var html = '';
    ['H', 'K', 'Sz', 'Cs', 'P', 'Szo', 'V'].forEach(d => {
      html += '<div class="text-center text-xs font-bold text-gray-500 py-2">' + d + '</div>';
    });
    for (var i = 0; i < startPad; i++) html += '<div></div>';
    for (var d = 1; d <= daysInMonth; d++) {
      var dateStr = new Date(year, month, d).toDateString();
      var tracked = state.trackedDays.indexOf(dateStr) !== -1;
      var inStreak = tracked && streakSet.has(dateStr);
      var isToday = today.getFullYear() === year && today.getMonth() === month && today.getDate() === d;
      
      var cls = 'aspect-square flex items-center justify-center rounded-xl text-sm font-semibold transition-all ';
      if (inStreak) cls += 'bg-gradient-to-br from-emerald-400 to-emerald-600 text-white shadow-md';
      else if (tracked) cls += 'bg-emerald-200 text-emerald-800';
      else if (isToday) cls += 'ring-2 ring-emerald-500 text-gray-800 dark:text-white';
      else cls += 'text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700';
      
      html += '<div class="' + cls + '">' + d + '</div>';
    }
    grid.innerHTML = html;
    
    var streak = state.streak || 0;
    var currentGoal = (Math.floor(streak / 10) + 1) * 10;
    if (streak === 0) currentGoal = 10;
    var pct = currentGoal > 0 ? Math.min(100, (streak / currentGoal) * 100) : 0;
    document.getElementById('sorozatcel-text').textContent = streak + ' / ' + currentGoal + ' nap';
    document.getElementById('sorozatcel-bar').style.width = pct + '%';
  }

  function renderProfile() {
    document.getElementById('profile-total-points').textContent = state.totalPoints;
    document.getElementById('profile-streak').textContent = state.streak;
    var friendsEl = document.getElementById('profile-friends');
    if (friendsEl) friendsEl.textContent = (state.friends && state.friends.length) || 0;
    document.getElementById('profile-username').textContent = state.currentUser ? (state.currentUser.displayName || state.currentUser.email || 'Felhasználó') : 'Felhasználó';
    updateAvatarDisplays();
  }

  function showToast(message, requestForAccept) {
    var container = document.getElementById('toast-container');
    if (!container) return;
    var toast = document.createElement('div');
    toast.className = 'toast-item pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-xl bg-white dark:bg-gray-800 shadow-xl border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-white max-w-sm animate-toast-in';
    toast.setAttribute('role', 'button');
    toast.tabIndex = 0;
    var icon = 'check';
    if (requestForAccept && requestForAccept.fromUid) {
      toast.dataset.fromUid = requestForAccept.fromUid;
      toast.dataset.displayName = requestForAccept.displayName || '';
      icon = 'user-plus';
    } else if (requestForAccept && requestForAccept.icon) {
      icon = requestForAccept.icon;
    }
    toast.innerHTML = '<i data-lucide="' + icon + '" class="w-5 h-5 text-emerald-500 shrink-0"></i><span class="text-sm font-medium">' + (message || '') + '</span>';
    container.appendChild(toast);
    if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
    setTimeout(function () {
      if (toast.parentNode) {
        toast.classList.add('toast-out');
        setTimeout(function () { if (toast.parentNode) toast.remove(); }, 300);
      }
    }, 5000);
  }

  function checkNewFriendRequestsAndShowToasts(prevRequestFromUids) {
    if (!state.friendRequests || !Array.isArray(state.friendRequests)) return;
    state.friendRequests.forEach(function (req) {
      var isNew = prevRequestFromUids.indexOf(req.fromUid) === -1;
      var alreadyShown = friendRequestToastShownFromUids[req.fromUid];
      if (isNew && !alreadyShown) {
        var name = (req.displayName && req.displayName.trim()) ? req.displayName.trim() : 'Valaki';
        showToast(name + ' baráti meghívást küldött!', req);
        friendRequestToastShownFromUids[req.fromUid] = true;
      }
    });
  }

  var addFriendOpenedFrom = null; // 'friends-list' | 'leaderboard' | null

  function openAddFriendModal(source) {
    addFriendOpenedFrom = source || 'leaderboard';
    var backBtn = document.getElementById('add-friend-modal-back');
    var closeBtn = document.getElementById('add-friend-modal-close');
    if (addFriendOpenedFrom === 'friends-list') {
      if (backBtn) backBtn.classList.remove('hidden');
      if (closeBtn) closeBtn.classList.add('hidden');
    } else {
      if (backBtn) backBtn.classList.add('hidden');
      if (closeBtn) closeBtn.classList.remove('hidden');
    }
    var modal = document.getElementById('modal-add-friend');
    var input = document.getElementById('add-friend-input');
    var errEl = document.getElementById('add-friend-error');
    if (errEl) { errEl.classList.add('hidden'); errEl.textContent = ''; }
    if (input) input.value = '';
    if (modal) {
      modal.classList.remove('hidden');
      modal.classList.add('flex');
      if (input) input.focus();
    }
    if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
  }

  function closeFriendsListModal() {
    var modal = document.getElementById('modal-friends-list');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  }

  function closeAddFriendModal() {
    var modal = document.getElementById('modal-add-friend');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
    addFriendOpenedFrom = null;
  }

  function onAddFriendBackOrClose() {
    if (addFriendOpenedFrom === 'friends-list') {
      closeAddFriendModal();
      openFriendsListModal();
    } else {
      closeAddFriendModal();
    }
  }

  function sendFriendRequest() {
    var input = document.getElementById('add-friend-input');
    var errEl = document.getElementById('add-friend-error');
    var submitBtn = document.getElementById('add-friend-submit');
    if (!input || !state.currentUser || !state.currentUser.uid) return;
    var query = (input.value || '').trim();
    if (!query) {
      if (errEl) { errEl.textContent = 'Add meg az e-mailt vagy a felhasználónevet.'; errEl.classList.remove('hidden'); }
      return;
    }
    if (errEl) { errEl.classList.add('hidden'); errEl.textContent = ''; }
    if (submitBtn) submitBtn.disabled = true;
    var firestoreDb = getDb();
    if (!firestoreDb) {
      if (errEl) { errEl.textContent = 'Firestore nem elérhető.'; errEl.classList.remove('hidden'); }
      if (submitBtn) submitBtn.disabled = false;
      return;
    }
    var usersRef = firestoreDb.collection('users');
    var normalizedEmail = query.indexOf('@') !== -1 ? query.toLowerCase() : '';
    var displayNameTerm = query;

    function validateAndSend(targetDoc) {
      if (!targetDoc) return false;
      var targetUid = targetDoc.id;
      if (targetUid === state.currentUser.uid) {
        if (errEl) { errEl.textContent = 'Magad nem adhatod hozzá barátként.'; errEl.classList.remove('hidden'); }
        if (submitBtn) submitBtn.disabled = false;
        return true;
      }
      var targetData = targetDoc.data();
      var blocked = targetData.blockedUsers && Array.isArray(targetData.blockedUsers) && targetData.blockedUsers.indexOf(state.currentUser.uid) !== -1;
      if (blocked) {
        if (errEl) { errEl.textContent = 'A meghívás küldése nem lehetséges.'; errEl.classList.remove('hidden'); }
        if (submitBtn) submitBtn.disabled = false;
        return true;
      }
      var friends = targetData.friends || [];
      if (friends.indexOf(state.currentUser.uid) !== -1) {
        if (errEl) { errEl.textContent = 'Már barátok vagytok.'; errEl.classList.remove('hidden'); }
        if (submitBtn) submitBtn.disabled = false;
        return true;
      }
      var friendRequests = targetData.friendRequests || [];
      var alreadyRequested = friendRequests.some(function (r) { return r.fromUid === state.currentUser.uid; });
      if (alreadyRequested) {
        if (errEl) { errEl.textContent = 'Már küldtél meghívást ennek a felhasználónak.'; errEl.classList.remove('hidden'); }
        if (submitBtn) submitBtn.disabled = false;
        return true;
      }
      var newRequest = { fromUid: state.currentUser.uid, displayName: state.currentUser.displayName || state.currentUser.email || 'Felhasználó', fromEmail: state.currentUser.email || null };
      friendRequests.push(newRequest);
      firestoreDb.collection('users').doc(targetUid).update({ friendRequests: friendRequests }).then(function () {
        closeAddFriendModal();
        showToast('Baráti kérelem sikeresen elküldve!');
        if (submitBtn) submitBtn.disabled = false;
      }).catch(function (err) {
        console.error('Send friend request error:', err);
        if (errEl) { errEl.textContent = 'Hiba történt. Próbáld újra.'; errEl.classList.remove('hidden'); }
        if (submitBtn) submitBtn.disabled = false;
      });
      return true;
    }

    var emailPromise = normalizedEmail ? usersRef.where('email', '==', normalizedEmail).limit(1).get() : Promise.resolve({ empty: true, docs: [] });
    var displayNamePromise = usersRef.where('displayName', '==', displayNameTerm).limit(1).get();

    Promise.all([emailPromise, displayNamePromise]).then(function (results) {
      var emailSnap = results[0];
      var displayNameSnap = results[1];
      var targetDoc = null;
      if (!emailSnap.empty) targetDoc = emailSnap.docs[0];
      if (!displayNameSnap.empty) {
        var byDisplay = displayNameSnap.docs[0];
        if (!targetDoc) targetDoc = byDisplay;
        else if (targetDoc.id !== byDisplay.id) targetDoc = normalizedEmail ? emailSnap.docs[0] : byDisplay;
      }
      if (targetDoc && validateAndSend(targetDoc)) return;
      if (errEl) { errEl.textContent = 'Nem található felhasználó ezzel az e-mail címmel vagy névvel.'; errEl.classList.remove('hidden'); }
      if (submitBtn) submitBtn.disabled = false;
    }).catch(function (err) {
      console.error('Send friend request error:', err);
      if (errEl) { errEl.textContent = 'Hiba történt. Próbáld újra.'; errEl.classList.remove('hidden'); }
      if (submitBtn) submitBtn.disabled = false;
    });
  }

  var pendingAcceptRequest = null;

  function openAcceptRequestModal(request) {
    pendingAcceptRequest = request;
    var modal = document.getElementById('modal-accept-request');
    var nameEl = document.getElementById('accept-request-name');
    var pointsEl = document.getElementById('accept-request-points');
    var streakEl = document.getElementById('accept-request-streak');
    var avatarEl = document.getElementById('accept-request-avatar');
    var iconEl = avatarEl ? avatarEl.querySelector('.accept-request-avatar-icon') : null;
    var badgesEl = document.getElementById('accept-request-badges');
    if (nameEl) nameEl.textContent = request.displayName || 'Felhasználó';
    if (pointsEl) pointsEl.textContent = '0';
    if (streakEl) streakEl.textContent = '0';
    if (avatarEl) { avatarEl.style.backgroundImage = ''; if (iconEl) iconEl.style.display = ''; }
    if (badgesEl) badgesEl.innerHTML = '';
    var firestoreDb = getDb();
    if (!firestoreDb || !request.fromUid) {
      var blockBtn = document.getElementById('block-request-btn');
      if (blockBtn) blockBtn.classList.add('hidden');
      if (modal) { modal.classList.remove('hidden'); modal.classList.add('flex'); }
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
      return;
    }
    firestoreDb.collection('users').doc(request.fromUid).get().then(function (doc) {
      if (doc.exists) {
        var d = doc.data();
        if (nameEl) nameEl.textContent = (d.displayName && d.displayName.trim()) ? d.displayName.trim() : (d.email || 'Felhasználó');
        if (pointsEl) pointsEl.textContent = d.totalPoints != null ? d.totalPoints : 0;
        if (streakEl) streakEl.textContent = d.streak != null ? d.streak : 0;
        if (d.avatarDataUrl && avatarEl) {
          avatarEl.style.backgroundImage = 'url(' + d.avatarDataUrl + ')';
          if (iconEl) iconEl.style.display = 'none';
        }
        var earned = getEarnedBadges(d);
        renderBadgesIntoEl(earned, badgesEl);
      }
      var blockBtn = document.getElementById('block-request-btn');
      if (blockBtn) {
        var count = (state.rejectCounts && state.rejectCounts[request.fromUid]) || 0;
        if (count >= 3) {
          blockBtn.classList.remove('hidden');
        } else {
          blockBtn.classList.add('hidden');
        }
      }
      if (modal) {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
      }
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
    }).catch(function () {
      if (modal) { modal.classList.remove('hidden'); modal.classList.add('flex'); }
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
    });
  }

  function rejectFriendRequest() {
    if (!pendingAcceptRequest || !state.currentUser || !state.currentUser.uid) return;
    var fromUid = pendingAcceptRequest.fromUid;
    var firestoreDb = getDb();
    if (!firestoreDb) return;
    var newRequests = (state.friendRequests || []).filter(function (r) { return r.fromUid !== fromUid; });
    state.friendRequests = newRequests;
    var rejectCounts = state.rejectCounts || {};
    rejectCounts[fromUid] = (rejectCounts[fromUid] || 0) + 1;
    state.rejectCounts = rejectCounts;
    var myRef = firestoreDb.collection('users').doc(state.currentUser.uid);
    myRef.update({ friendRequests: newRequests, rejectCounts: rejectCounts }).then(function () {
      pendingAcceptRequest = null;
      closeModals();
      updateNavNotifications();
    }).catch(function (err) {
      console.error('Reject friend request error:', err);
    });
  }

  function blockUserRequest() {
    if (!pendingAcceptRequest || !state.currentUser || !state.currentUser.uid) return;
    var fromUid = pendingAcceptRequest.fromUid;
    var firestoreDb = getDb();
    if (!firestoreDb) return;
    var newRequests = (state.friendRequests || []).filter(function (r) { return r.fromUid !== fromUid; });
    state.friendRequests = newRequests;
    var blockedUsers = (state.blockedUsers || []).slice();
    if (blockedUsers.indexOf(fromUid) === -1) blockedUsers.push(fromUid);
    state.blockedUsers = blockedUsers;
    var myRef = firestoreDb.collection('users').doc(state.currentUser.uid);
    myRef.update({ friendRequests: newRequests, blockedUsers: blockedUsers }).then(function () {
      pendingAcceptRequest = null;
      closeModals();
      closeNotificationsDropdown();
      updateNavNotifications();
    }).catch(function (err) {
      console.error('Block user error:', err);
    });
  }

  function acceptFriendRequest() {
    if (!pendingAcceptRequest || !state.currentUser || !state.currentUser.uid) return;
    var fromUid = pendingAcceptRequest.fromUid;
    var firestoreDb = getDb();
    if (!firestoreDb) return;
    var myRef = firestoreDb.collection('users').doc(state.currentUser.uid);
    var senderRef = firestoreDb.collection('users').doc(fromUid);
    var myFriends = (state.friends || []).slice();
    if (myFriends.indexOf(fromUid) === -1) myFriends.push(fromUid);
    var newRequests = (state.friendRequests || []).filter(function (r) { return r.fromUid !== fromUid; });
    state.friendRequests = newRequests;
    state.friends = myFriends;
    state.friendCount = myFriends.length;
    myRef.update({ friendRequests: newRequests, friends: myFriends, friendCount: myFriends.length }).then(function () {
      return senderRef.get();
    }).then(function (doc) {
      if (!doc.exists) return;
      var senderFriends = (doc.data().friends || []).slice();
      if (senderFriends.indexOf(state.currentUser.uid) === -1) senderFriends.push(state.currentUser.uid);
      return senderRef.update({ friends: senderFriends, friendCount: senderFriends.length });
    }).then(function () {
      pendingAcceptRequest = null;
      closeModals();
      updateNavNotifications();
      renderLeaderboard();
      renderProfile();
    }).catch(function (err) {
      console.error('Accept friend request error:', err);
    });
  }

  function renderLeaderboard() {
    var listEl = document.getElementById('leaderboard-list');
    if (!listEl) return;
    var ac = state.activeChallenges || { bringFood: 0, highScore: 0, walkBike: 0 };
    document.querySelectorAll('[data-challenge]').forEach(li => {
      var key = li.getAttribute('data-challenge');
      var el = li.querySelector('[data-challenge-progress]');
      if (el) el.textContent = ac[key] !== undefined ? ac[key] : 0;
    });
    var myUid = state.currentUser ? state.currentUser.uid : null;
    var myPoints = state.totalPoints || 0;
    var myName = state.currentUser ? (state.currentUser.displayName || state.currentUser.email || 'Te') : 'Te';
    var myAvatar = state.avatarDataUrl || null;
    var friendUids = state.friends || [];
    if (friendUids.length === 0 && !myUid) {
      listEl.innerHTML = '<li class="flex items-center gap-3 px-4 py-3 border-b border-gray-100 dark:border-gray-700 text-gray-500 dark:text-gray-400 text-sm">Nincs még barátod. Kattints a &quot;Barátok hozzáadása&quot; gombra.</li>';
      return;
    }
    var allUids = [myUid].concat(friendUids.filter(function (uid) { return uid !== myUid; }));
    var firestoreDb = getDb();
    if (!firestoreDb) {
      var row = '<li class="flex items-center gap-3 px-4 py-3 md:py-4 border-b border-gray-100 dark:border-gray-700 bg-emerald-50/50 dark:bg-emerald-900/20">';
      row += '<span class="font-bold text-amber-500 text-base md:text-lg">1</span>';
      row += '<span class="flex-1 font-bold text-gray-800 dark:text-white">' + escapeHtml(myName) + '</span>';
      row += '<span class="font-bold text-emerald-500 text-base md:text-lg">' + myPoints + ' pt</span></li>';
      listEl.innerHTML = row;
      return;
    }
    var promises = allUids.map(function (uid) {
      if (!uid) return Promise.resolve(null);
      return firestoreDb.collection('users').doc(uid).get().then(function (doc) {
        if (!doc.exists) return { uid: uid, displayName: '?', totalPoints: 0, avatarDataUrl: null };
        var d = doc.data();
        return { uid: uid, displayName: (d.displayName && d.displayName.trim()) ? d.displayName.trim() : (d.email || 'Felhasználó'), totalPoints: d.totalPoints != null ? d.totalPoints : 0, avatarDataUrl: d.avatarDataUrl || null, isMe: uid === myUid };
      });
    });
    Promise.all(promises).then(function (users) {
      users = users.filter(Boolean);
      users.forEach(function (u) { if (!u.isMe && u.uid) friendUidToNameCache[u.uid] = u.displayName || 'Barát'; });
      users.sort(function (a, b) { return (b.totalPoints || 0) - (a.totalPoints || 0); });
      var html = '';
      users.forEach(function (u, idx) {
        var rank = idx + 1;
        var rankCls = rank === 1 ? 'text-amber-500' : (rank === 2 ? 'text-gray-400' : 'text-amber-700');
        var rowCls = u.isMe ? 'flex items-center gap-3 px-4 py-3 md:py-4 border-b border-gray-100 dark:border-gray-700 bg-emerald-50/50 dark:bg-emerald-900/20' : 'flex items-center gap-3 px-4 py-3 md:py-4 border-b border-gray-100 dark:border-gray-700 leaderboard-friend-row cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors';
        var name = u.isMe ? 'Te' : (u.displayName || 'Felhasználó');
        var avatarStyle = u.avatarDataUrl ? 'background-image:url(' + u.avatarDataUrl + ');background-size:cover;background-position:center' : '';
        html += '<li class="' + rowCls + '"' + (u.isMe ? '' : ' data-friend-uid="' + escapeHtml(u.uid) + '"') + '>';
        html += '<span class="font-bold ' + rankCls + ' text-base md:text-lg w-6">' + rank + '</span>';
        html += '<div class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex-shrink-0 ' + (u.avatarDataUrl ? '' : 'flex items-center justify-center') + '" style="' + avatarStyle + '">';
        if (!u.avatarDataUrl) html += '<i data-lucide="user" class="w-4 h-4 text-gray-500"></i>';
        html += '</div>';
        html += '<span class="flex-1 font-semibold text-gray-800 dark:text-white truncate">' + escapeHtml(name) + '</span>';
        html += '<span class="font-semibold text-emerald-500 text-base md:text-lg">' + (u.totalPoints || 0) + ' pt</span>';
        html += '</li>';
      });
      listEl.innerHTML = html;
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
    });
  }

  function escapeHtml(s) {
    if (!s) return '';
    var div = document.createElement('div');
    div.textContent = s;
    return div.innerHTML;
  }

  /** Compress image to JPEG via canvas to stay under Firestore 1MB. Returns data URL or null. */
  function compressImageForFirestore(file, maxSize = 256, quality = 0.7, callback) {
    var url = URL.createObjectURL(file);
    var img = new Image();
    img.onload = function () {
      URL.revokeObjectURL(url);
      var w = img.naturalWidth;
      var h = img.naturalHeight;
      if (w > maxSize || h > maxSize) {
        if (w > h) { h = Math.round((h * maxSize) / w); w = maxSize; } else { w = Math.round((w * maxSize) / h); h = maxSize; }
      }
      var canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      var ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, w, h);
      var dataUrl = canvas.toDataURL('image/jpeg', quality);
      if (typeof callback === 'function') callback(dataUrl);
    };
    img.onerror = function () { URL.revokeObjectURL(url); if (typeof callback === 'function') callback(null); };
    img.src = url;
  }

  var pendingFriendProfileUid = null;

  function getChatId(uid1, uid2) {
    if (!uid1 || !uid2) return '';
    return [uid1, uid2].sort().join('_');
  }

  var chatUnsubscribe = null;
  var currentChatFriendUid = null;
  var currentChatFriendName = '';
  var chatOpenedFrom = null; // 'friends-list' | 'leaderboard' | null

  function openChatModal(friendUid, friendName, from) {
    if (!state.currentUser || !friendUid || friendUid === state.currentUser.uid) return;
    if (chatUnsubscribe && typeof chatUnsubscribe === 'function') {
      chatUnsubscribe();
      chatUnsubscribe = null;
    }
    chatOpenedFrom = from || null;
    currentChatFriendUid = friendUid;
    currentChatFriendName = friendName || 'Barát';
    var titleEl = document.getElementById('chat-modal-title');
    if (titleEl) titleEl.textContent = currentChatFriendName;
    var container = document.getElementById('chat-messages');
    if (container) container.innerHTML = '<p class="text-sm text-gray-500 text-center py-4">Üzenetek betöltése...</p>';
    var firestoreDb = getDb();
    if (!firestoreDb) {
      if (container) container.innerHTML = '<p class="text-sm text-gray-500 text-center py-4">Nincs kapcsolat.</p>';
      document.getElementById('modal-chat').classList.remove('hidden');
      document.getElementById('modal-chat').classList.add('flex');
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
      return;
    }
    var chatId = getChatId(state.currentUser.uid, friendUid);
    var messagesRef = firestoreDb.collection('chats').doc(chatId).collection('messages');
    chatUnsubscribe = messagesRef.orderBy('timestamp', 'asc').limit(100).onSnapshot(
      function (snap) {
        var el = document.getElementById('chat-messages');
        if (!el) return;
        el.innerHTML = '';
        if (!snap || !snap.docs || snap.docs.length === 0) {
          chatUnreadCountByChatId[chatId] = 0;
          updateNavNotifications();
          el.innerHTML = '<p class="text-sm text-gray-500 dark:text-gray-400 text-center py-4">Még nincs üzenet. Kezdd el a beszélgetést!</p>';
          if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
          return;
        }
        var me = state.currentUser ? state.currentUser.uid : null;
        var batch = firestoreDb.batch();
        var hasUnreadToMark = false;
        snap.docs.forEach(function (doc) {
          var d = doc.data();
          var senderId = d.senderId || '';
          var isRead = d.isRead;
          if (senderId !== me && isRead !== true) {
            batch.update(doc.ref, { isRead: true });
            hasUnreadToMark = true;
          }
        });
        if (hasUnreadToMark) batch.commit().catch(function (err) { console.error('Mark read error:', err); });
        snap.docs.forEach(function (doc) {
          var d = doc.data();
          var senderId = d.senderId || '';
          var text = (d.text || '').trim();
          var ts = d.timestamp;
          var dateStr = '';
          if (ts && (ts.toDate && typeof ts.toDate === 'function')) dateStr = ts.toDate().toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' });
          else if (ts && ts.seconds) dateStr = new Date(ts.seconds * 1000).toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' });
          var isMine = senderId === me;
          var div = document.createElement('div');
          div.className = 'chat-msg ' + (isMine ? 'mine' : 'theirs') + ' rounded-xl px-3 py-2 text-sm';
          div.innerHTML = '<span class="block">' + escapeHtml(text) + '</span><span class="block text-xs opacity-75 mt-1">' + escapeHtml(dateStr) + '</span>';
          el.appendChild(div);
        });
        chatUnreadCountByChatId[chatId] = 0;
        updateNavNotifications();
        el.scrollTop = el.scrollHeight;
        if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
      },
      function (err) {
        console.error('Chat snapshot error:', err);
        var el = document.getElementById('chat-messages');
        if (el) el.innerHTML = '<p class="text-sm text-red-500 text-center py-4">Hiba történt.</p>';
      }
    );
    document.getElementById('modal-chat').classList.remove('hidden');
    document.getElementById('modal-chat').classList.add('flex');
    if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
  }

  function closeChatModal() {
    if (chatUnsubscribe && typeof chatUnsubscribe === 'function') {
      chatUnsubscribe();
      chatUnsubscribe = null;
    }
    currentChatFriendUid = null;
    currentChatFriendName = '';
    chatOpenedFrom = null;
    document.getElementById('modal-chat').classList.add('hidden');
    document.getElementById('modal-chat').classList.remove('flex');
  }

  function onChatBackOrClose() {
    if (chatOpenedFrom === 'friends-list') {
      closeChatModal();
      openFriendsListModal();
    } else {
      closeChatModal();
    }
  }

  function sendChatMessage() {
    var input = document.getElementById('chat-input');
    if (!input || !state.currentUser || !currentChatFriendUid) return;
    var text = (input.value || '').trim();
    if (!text) return;
    var firestoreDb = getDb();
    if (!firestoreDb) return;
    var chatId = getChatId(state.currentUser.uid, currentChatFriendUid);
    var messagesRef = firestoreDb.collection('chats').doc(chatId).collection('messages');
    messagesRef.add({
      senderId: state.currentUser.uid,
      text: text,
      timestamp: firebase.firestore.FieldValue.serverTimestamp(),
      isRead: false
    }).then(function () {
      input.value = '';
    }).catch(function (err) {
      console.error('Send message error:', err);
    });
  }

  var friendsListData = [];

  function renderFriendsListModal(filter) {
    var listEl = document.getElementById('friends-list-modal-list');
    if (!listEl) return;
    var q = (filter || '').toLowerCase().trim();
    var items = friendsListData;
    if (q) items = items.filter(function (f) { return (f.displayName || '').toLowerCase().indexOf(q) !== -1; });
    if (items.length === 0) {
      listEl.innerHTML = '<li class="text-sm text-gray-500 dark:text-gray-400 text-center py-6">' + (q ? 'Nincs találat.' : 'Nincs barátod.') + '</li>';
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
      return;
    }
    var html = items.map(function (f) {
      var name = (f.displayName && f.displayName.trim()) ? escapeHtml(f.displayName.trim()) : 'Felhasználó';
      var nameAttr = (f.displayName && f.displayName.trim()) ? String(f.displayName.trim()).replace(/"/g, '&quot;') : 'Felhasználó';
      var avatarStyle = f.avatarDataUrl ? 'background-image:url(' + f.avatarDataUrl + ');background-size:cover;background-position:center' : '';
      return '<li class="friends-list-item flex items-center gap-3 p-3 rounded-xl border border-gray-100 dark:border-gray-700" data-friend-uid="' + escapeHtml(f.uid) + '" data-friend-name="' + nameAttr + '"><div class="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex-shrink-0 ' + (f.avatarDataUrl ? '' : 'flex items-center justify-center') + '" style="' + avatarStyle + '">' + (!f.avatarDataUrl ? '<i data-lucide="user" class="w-5 h-5 text-gray-500"></i>' : '') + '</div><span class="font-semibold text-gray-800 dark:text-white truncate flex-1">' + name + '</span><i data-lucide="message-circle" class="w-5 h-5 text-emerald-500 shrink-0"></i></li>';
    }).join('');
    listEl.innerHTML = html;
    if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
  }

  function openFriendsListModal() {
    var modal = document.getElementById('modal-friends-list');
    var searchEl = document.getElementById('friends-list-search');
    if (searchEl) searchEl.value = '';
    friendsListData = [];
    var firestoreDb = getDb();
    if (!firestoreDb || !state.currentUser || !state.friends || state.friends.length === 0) {
      renderFriendsListModal();
      if (modal) { modal.classList.remove('hidden'); modal.classList.add('flex'); }
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
      return;
    }
    var promises = state.friends.map(function (uid) {
      return firestoreDb.collection('users').doc(uid).get().then(function (doc) {
        if (!doc.exists) return { uid: uid, displayName: '?', avatarDataUrl: null };
        var d = doc.data();
        return { uid: uid, displayName: (d.displayName && d.displayName.trim()) ? d.displayName.trim() : (d.email || 'Felhasználó'), avatarDataUrl: d.avatarDataUrl || null };
      });
    });
    Promise.all(promises).then(function (arr) {
      friendsListData = arr;
      arr.forEach(function (f) { if (f.uid) friendUidToNameCache[f.uid] = f.displayName || 'Barát'; });
      renderFriendsListModal();
      if (modal) { modal.classList.remove('hidden'); modal.classList.add('flex'); }
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
    });
  }

  function openFriendProfileModal(friendUid) {
    if (!friendUid || friendUid === (state.currentUser && state.currentUser.uid)) return;
    pendingFriendProfileUid = friendUid;
    var modal = document.getElementById('modal-friend-profile');
    var nameEl = document.getElementById('friend-profile-name');
    var pointsEl = document.getElementById('friend-profile-points');
    var streakEl = document.getElementById('friend-profile-streak');
    var avatarEl = document.getElementById('friend-profile-avatar');
    var iconEl = avatarEl ? avatarEl.querySelector('.friend-profile-avatar-icon') : null;
    var badgesEl = document.getElementById('friend-profile-badges');
    if (nameEl) nameEl.textContent = '—';
    if (pointsEl) pointsEl.textContent = '0';
    if (streakEl) streakEl.textContent = '0';
    if (avatarEl) { avatarEl.style.backgroundImage = ''; if (iconEl) iconEl.style.display = ''; }
    if (badgesEl) badgesEl.innerHTML = '';
    var firestoreDb = getDb();
    if (!firestoreDb) {
      if (modal) { modal.classList.remove('hidden'); modal.classList.add('flex'); }
      return;
    }
    firestoreDb.collection('users').doc(friendUid).get().then(function (doc) {
      if (doc.exists) {
        var d = doc.data();
        if (nameEl) nameEl.textContent = (d.displayName && d.displayName.trim()) ? d.displayName.trim() : (d.email || 'Felhasználó');
        if (pointsEl) pointsEl.textContent = d.totalPoints != null ? d.totalPoints : 0;
        if (streakEl) streakEl.textContent = d.streak != null ? d.streak : 0;
        if (d.avatarDataUrl && avatarEl) {
          avatarEl.style.backgroundImage = 'url(' + d.avatarDataUrl + ')';
          if (iconEl) iconEl.style.display = 'none';
        }
        var earned = getEarnedBadges(d);
        renderBadgesIntoEl(earned, badgesEl);
      }
      if (modal) { modal.classList.remove('hidden'); modal.classList.add('flex'); }
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
    }).catch(function () {
      if (modal) { modal.classList.remove('hidden'); modal.classList.add('flex'); }
    });
  }

  function removeFriend() {
    if (!pendingFriendProfileUid || !state.currentUser || !state.currentUser.uid) return;
    var friendUid = pendingFriendProfileUid;
    var firestoreDb = getDb();
    if (!firestoreDb) return;
    var myRef = firestoreDb.collection('users').doc(state.currentUser.uid);
    var friendRef = firestoreDb.collection('users').doc(friendUid);
    var myFriends = (state.friends || []).filter(function (uid) { return uid !== friendUid; });
    state.friends = myFriends;
    state.friendCount = myFriends.length;
    friendRef.get().then(function (doc) {
      var otherFriends = (doc.exists && doc.data().friends) ? doc.data().friends.filter(function (uid) { return uid !== state.currentUser.uid; }) : [];
      var batch = firestoreDb.batch();
      batch.update(myRef, { friends: myFriends, friendCount: myFriends.length });
      batch.update(friendRef, { friends: otherFriends, friendCount: otherFriends.length });
      return batch.commit();
    }).then(function () {
      pendingFriendProfileUid = null;
      closeModals();
      renderLeaderboard();
      renderProfile();
    }).catch(function (err) {
      console.error('Remove friend error:', err);
    });
  }

  function bindEvents() {
    document.getElementById('tab-login').addEventListener('click', () => {
      document.getElementById('tab-login').className = 'flex-1 py-2.5 rounded-lg font-semibold text-sm transition-all bg-white dark:bg-gray-600 text-emerald-600 dark:text-emerald-400 shadow';
      document.getElementById('tab-register').className = 'flex-1 py-2.5 rounded-lg font-semibold text-sm transition-all text-gray-600 dark:text-gray-400';
      document.getElementById('auth-submit').textContent = 'Bejelentkezés';
      document.getElementById('auth-hint').textContent = 'Nincs még fiókod? Regisztrálj fent.';
      var wrap = document.getElementById('auth-display-name-wrap');
      if (wrap) wrap.classList.add('hidden');
    });

    document.getElementById('tab-register').addEventListener('click', () => {
      document.getElementById('tab-register').className = 'flex-1 py-2.5 rounded-lg font-semibold text-sm transition-all bg-white dark:bg-gray-600 text-emerald-600 dark:text-emerald-400 shadow';
      document.getElementById('tab-login').className = 'flex-1 py-2.5 rounded-lg font-semibold text-sm transition-all text-gray-600 dark:text-gray-400';
      document.getElementById('auth-submit').textContent = 'Regisztráció';
      document.getElementById('auth-hint').textContent = 'Már van fiókod? Jelentkezz be fent.';
      var wrap = document.getElementById('auth-display-name-wrap');
      if (wrap) wrap.classList.remove('hidden');
    });

    document.getElementById('auth-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var authErrorEl = document.getElementById('auth-error');
      if (authErrorEl) {
        authErrorEl.classList.add('hidden');
        authErrorEl.textContent = '';
      }
      var emailEl = document.getElementById('auth-email');
      var passwordEl = document.getElementById('auth-password');
      var email = emailEl ? emailEl.value.trim() : '';
      var password = passwordEl ? passwordEl.value : '';
      var isLogin = document.getElementById('auth-submit').textContent === 'Bejelentkezés';
      var submitBtn = document.getElementById('auth-submit');

      var auth = getAuth();
      if (!auth) {
        var msg = 'Firebase nem elérhető. Ellenőrizd a böngésző konzolt és a firebaseConfig-ot.';
        if (authErrorEl) { authErrorEl.textContent = msg; authErrorEl.classList.remove('hidden'); }
        alert(msg);
        return false;
      }
      if (!email || !password) {
        var fillMsg = 'Kérlek töltsd ki az e-mail és jelszó mezőket.';
        if (authErrorEl) { authErrorEl.textContent = fillMsg; authErrorEl.classList.remove('hidden'); }
        alert(fillMsg);
        return false;
      }

      submitBtn.disabled = true;
      function showError(msg) {
        submitBtn.disabled = false;
        if (authErrorEl) { authErrorEl.textContent = msg; authErrorEl.classList.remove('hidden'); }
        alert(msg);
      }
      function clearError() {
        submitBtn.disabled = false;
        if (authErrorEl) { authErrorEl.classList.add('hidden'); authErrorEl.textContent = ''; }
      }

      if (isLogin) {
        loginWithFirebase(email, password)
          .then(function () {
            return loadAppStateFromFirestore(state.currentUser);
          })
          .then(function () {
            clearError();
            if (state.currentUser) showMain();
          })
          .catch(function (err) {
            var msg = (err && (err.message || err.code)) ? (err.message || err.code) : String(err);
            if (msg.indexOf('auth/invalid-credential') !== -1 || msg.indexOf('auth/wrong-password') !== -1 || msg.indexOf('auth/user-not-found') !== -1 || msg.indexOf('auth/invalid-email') !== -1) msg = 'Érvénytelen e-mail vagy jelszó.';
            showError(msg);
          });
      } else {
        var displayNameEl = document.getElementById('auth-display-name');
        var displayName = (displayNameEl && displayNameEl.value && displayNameEl.value.trim()) ? displayNameEl.value.trim() : email;
        isDisplayNameTaken(displayName, null).then(function (taken) {
          if (taken) {
            showError('Ez a felhasználónév már foglalt!');
            return;
          }
          registerWithFirebase(email, password, displayName)
            .then(function () {
              return loadAppStateFromFirestore(state.currentUser);
            })
            .then(function () {
              clearError();
              if (state.currentUser) showMain();
            })
            .catch(function (err) {
              var msg = (err && (err.message || err.code)) ? (err.message || err.code) : String(err);
              if (msg.indexOf('auth/email-already-in-use') !== -1) msg = 'Ez az e-mail cím már regisztrálva van.';
              else if (msg.indexOf('auth/weak-password') !== -1) msg = 'A jelszónak legalább 6 karakter hosszúnak kell lennie.';
              else if (msg.indexOf('auth/invalid-email') !== -1) msg = 'Érvénytelen e-mail cím.';
              showError(msg);
            });
        });
      }
      return false;
    });

    document.getElementById('calc-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var todayStr = getTodayString();
      if (state.lastEntryDate === todayStr) {
        document.getElementById('daily-limit-modal').classList.remove('hidden');
        document.getElementById('daily-limit-modal').classList.add('flex');
        document.getElementById('daily-limit-content').classList.remove('scale-95');
        document.getElementById('daily-limit-content').classList.add('scale-100');
        return;
      }
      var b = getCo2Breakdown();
      var score = co2ToScore(b.total);
      
      var foodType = document.getElementById('calc-food').value;
      var hasBottle = document.getElementById('calc-bonus-bottle').checked;
      var qualifiesForFoodChallenge = hasBottle || foodType === 'vegan' || foodType === 'otthoni';
      
      var vehicle = document.getElementById('calc-vehicle').value;
      
      showResults(b, score, qualifiesForFoodChallenge, vehicle);
    });

    document.getElementById('daily-limit-close').addEventListener('click', () => {
      document.getElementById('daily-limit-modal').classList.add('hidden');
      document.getElementById('daily-limit-modal').classList.remove('flex');
      document.getElementById('daily-limit-content').classList.remove('scale-100');
      document.getElementById('daily-limit-content').classList.add('scale-95');
    });

    document.getElementById('btn-add-friends').addEventListener('click', function () {
      addFriendOpenedFrom = 'leaderboard';
      openAddFriendModal('leaderboard');
    });
    document.getElementById('btn-friends-list').addEventListener('click', openFriendsListModal);
    document.getElementById('friends-list-add-friend-btn').addEventListener('click', function () {
      closeFriendsListModal();
      openAddFriendModal('friends-list');
    });
    document.getElementById('add-friend-modal-close').addEventListener('click', onAddFriendBackOrClose);
    document.getElementById('add-friend-modal-back').addEventListener('click', onAddFriendBackOrClose);
    document.getElementById('add-friend-submit').addEventListener('click', sendFriendRequest);
    document.getElementById('add-friend-input').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); sendFriendRequest(); }
    });
    document.getElementById('accept-request-btn').addEventListener('click', acceptFriendRequest);
    document.getElementById('reject-request-btn').addEventListener('click', rejectFriendRequest);
    document.getElementById('block-request-btn').addEventListener('click', blockUserRequest);
    document.getElementById('friend-profile-remove-btn').addEventListener('click', removeFriend);
    document.getElementById('friend-profile-chat-btn').addEventListener('click', function () {
      if (!pendingFriendProfileUid) return;
      var nameEl = document.getElementById('friend-profile-name');
      var name = nameEl ? nameEl.textContent.trim() : 'Barát';
      closeModals();
      openChatModal(pendingFriendProfileUid, name, 'leaderboard');
    });
    document.getElementById('friends-list-search').addEventListener('input', function () {
      var q = this.value || '';
      renderFriendsListModal(q);
    });
    document.getElementById('chat-send').addEventListener('click', sendChatMessage);
    document.getElementById('chat-input').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); sendChatMessage(); }
    });
    var chatBackBtn = document.querySelector('#modal-chat .chat-back');
    if (chatBackBtn) chatBackBtn.addEventListener('click', onChatBackOrClose);
    var chatCloseBtn = document.querySelector('#modal-chat .chat-close');
    if (chatCloseBtn) chatCloseBtn.addEventListener('click', onChatBackOrClose);
    document.addEventListener('click', function (e) {
      var toast = e.target.closest('.toast-item');
      if (toast && toast.dataset.fromUid) {
        var fromUid = toast.dataset.fromUid;
        var req = (state.friendRequests || []).find(function (r) { return r.fromUid === fromUid; });
        if (req) openAcceptRequestModal(req);
        return;
      }
      var friendRow = e.target.closest('.leaderboard-friend-row');
      if (friendRow && friendRow.dataset.friendUid) {
        openFriendProfileModal(friendRow.dataset.friendUid);
      }
      var friendsListItem = e.target.closest('.friends-list-item');
      if (friendsListItem && friendsListItem.dataset.friendUid) {
        var uid = friendsListItem.dataset.friendUid;
        var name = friendsListItem.dataset.friendName || 'Barát';
        closeModals();
        openChatModal(uid, name, 'friends-list');
      }
    });

    document.getElementById('nav-calendar').addEventListener('click', () => openModal('calendar'));
    document.getElementById('nav-notifications').addEventListener('click', function (e) {
      e.stopPropagation();
      toggleNotificationsDropdown();
    });
    document.addEventListener('click', function (e) {
      var dd = document.getElementById('notifications-dropdown');
      var btn = document.getElementById('nav-notifications');
      if (dd && btn && !dd.contains(e.target) && !btn.contains(e.target)) closeNotificationsDropdown();
    });
    var notifDropdown = document.getElementById('notifications-dropdown');
    if (notifDropdown) notifDropdown.addEventListener('click', function (e) { e.stopPropagation(); });
    document.getElementById('notifications-list').addEventListener('click', function (e) {
      var item = e.target.closest('.notification-item');
      if (!item) return;
      var type = item.dataset.type || 'friend-request';
      if (type === 'chat') {
        var friendUid = item.dataset.friendUid;
        var friendName = item.dataset.friendName || 'Barát';
        if (friendUid) {
          closeNotificationsDropdown();
          openChatModal(friendUid, friendName);
        }
        return;
      }
      var fromUid = item.dataset.fromUid;
      if (fromUid) {
        var req = (state.friendRequests || []).find(function (r) { return r.fromUid === fromUid; });
        if (req) {
          closeNotificationsDropdown();
          openAcceptRequestModal(req);
        }
      }
    });
    document.getElementById('nav-settings').addEventListener('click', () => {
      document.getElementById('settings-username').value = state.currentUser ? (state.currentUser.displayName || state.currentUser.email || '') : '';
      openModal('settings');
    });
    
    document.getElementById('btn-open-info').addEventListener('click', () => {
      document.getElementById('info-menu').classList.remove('hidden');
      document.getElementById('info-menu').classList.add('flex');
      document.getElementById('info-details').classList.add('hidden');
      document.getElementById('info-details').classList.remove('flex');
      openModal('info');
    });

    document.querySelectorAll('.info-nav-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const targetId = btn.getAttribute('data-target');
        const title = btn.getAttribute('data-title');
        
        document.getElementById('info-menu').classList.add('hidden');
        document.getElementById('info-menu').classList.remove('flex');
        
        document.getElementById('info-details').classList.remove('hidden');
        document.getElementById('info-details').classList.add('flex');
        document.getElementById('info-detail-title').textContent = title;
        
        document.querySelectorAll('.info-content-block').forEach(el => el.classList.add('hidden'));
        document.getElementById(targetId).classList.remove('hidden');
      });
    });

    document.getElementById('info-btn-back').addEventListener('click', () => {
      document.getElementById('info-details').classList.add('hidden');
      document.getElementById('info-details').classList.remove('flex');
      document.getElementById('info-menu').classList.remove('hidden');
      document.getElementById('info-menu').classList.add('flex');
    });
    
    document.querySelectorAll('.close-modal').forEach(btn => {
      btn.addEventListener('click', closeModals);
    });

    document.getElementById('calendar-prev').addEventListener('click', () => {
      calendarCurrent.month--;
      if (calendarCurrent.month < 0) { calendarCurrent.month = 11; calendarCurrent.year--; }
      renderCalendar();
    });
    document.getElementById('calendar-next').addEventListener('click', () => {
      calendarCurrent.month++;
      if (calendarCurrent.month > 11) { calendarCurrent.month = 0; calendarCurrent.year++; }
      renderCalendar();
    });

    document.getElementById('toggle-dark').addEventListener('click', () => {
      state.darkMode = !state.darkMode;
      saveTheme();
      applyPrefs();
      if(chartDonut) drawDonut(state.lastCalc ? state.lastCalc.breakdown : {transport: 0, food: 0, digital: 0, bonus: 0});
    });

    document.getElementById('toggle-notifications').addEventListener('click', () => {
      setNotifications(!state.notifications);
    });

    document.getElementById('settings-save-name').addEventListener('click', function () {
      var input = document.getElementById('settings-username');
      if (!input || !state.currentUser) return;
      var name = input.value.trim() || state.currentUser.email || 'Felhasználó';
      isDisplayNameTaken(name, state.currentUser.uid).then(function (taken) {
        if (taken) {
          showToast('Ez a felhasználónév már foglalt!', { icon: 'alert-triangle' });
          return;
        }
        state.currentUser.displayName = name;
        saveAppState().then(function () {
          showToast('Név elmentve!');
          syncProfileAndSettings();
        }).catch(function (e) {
          console.error('Save failed:', e);
        });
      });
    });
    
    document.getElementById('btn-logout').addEventListener('click', logout);
    
    document.getElementById('avatar-input').addEventListener('change', function () {
      if (this.files && this.files[0]) {
        var file = this.files[0];
        compressImageForFirestore(file, 256, 0.7, function (dataUrl) {
          if (dataUrl) {
            state.avatarDataUrl = dataUrl;
            saveAppState().catch(function (e) { console.error('Save failed:', e); });
            updateAvatarDisplays();
          }
        });
        this.value = '';
      }
    });
    
    window.addEventListener('resize', () => {
        if(typeof chartDonut !== 'undefined' && chartDonut) chartDonut.resize();
    });
  }

  function init() {
    refreshLucide();
    initFirebase();
    loadPrefs();
    applyPrefs();
    bindEvents();
    runSplash();
    setupAuthStateListener();
    setInterval(checkFixedTimeReminders, 60 * 1000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();